 <!DOCTYPE html>
 <html lang="en">

 <head>
     <meta charset="utf-8">
     <meta content="width=device-width, initial-scale=1.0" name="viewport">

     <title>Medicio Bootstrap Template - Index</title>
     <meta content="" name="description">
     <meta content="" name="keywords">

     <!-- Favicons -->
     <link href="../multiple/assets/img/favicon.png" rel="icon">
     <link href="../multiple/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

     <!-- Google Fonts -->
     <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

     <!-- Vendor CSS Files -->
     <link href="vendor/bootstrap.min.css" rel="stylesheet">

     <!-- Template Main CSS File -->
     <link href="../multiple/assets/css/style.css" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
     <style>
         p,
         h1,
         h2,
         h3,
         h4,
         h5,
         h6,
         li,
         ul,
         ol,
         a,
         body {
             font-family: 'Nunito', sans-serif;
             font-size: larger;
         }
     </style>
 </head>